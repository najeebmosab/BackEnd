export const environment = {
  production: true,
  Api:"https://localhost:44342/api/"
};
