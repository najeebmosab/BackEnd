import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layoutpage',
  templateUrl: './layoutpage.component.html',
  styleUrls: ['./layoutpage.component.css']
})
export class LayoutpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
