import { SortOrdersPipe } from './sort-orders.pipe';

describe('SortOrdersPipe', () => {
  it('create an instance', () => {
    const pipe = new SortOrdersPipe();
    expect(pipe).toBeTruthy();
  });
});
