import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-lay-out',
  templateUrl: './landing-lay-out.component.html',
  styleUrls: ['./landing-lay-out.component.css']
})
export class LandingLayOutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
