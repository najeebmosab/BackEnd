import { LoginCustomerComponent } from './components/login-customer/login-customer.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthLayOutComponent } from './components/auth-lay-out/auth-lay-out.component';

const routes: Routes = [
  {path:"",component:LoginCustomerComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuthRoutingModule {}
