import { CartAPI } from './../../../../shared/model/cart-api';
import { CartService } from './../../../../shared/Service/cart-service.service';
import { Router } from '@angular/router';
import { UserAPI } from './../../../../shared/model/user-api';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, DoCheck, OnInit } from '@angular/core';
import { UserAPIService } from 'src/app/shared/Service/user-api.service';
import {Location} from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css'],
})
export class SingupComponent implements OnInit, DoCheck {
  SingUpForm: FormGroup;//virable for form
  res: UserAPI;
  Token:string;
  img='defultImg.png';
  notEqual = false;
  // all what we need to coniction with Data base
  constructor(private http: UserAPIService, private _Router:Router,private cartService:CartService ) {}
  ngDoCheck(): void {

  }

  // start validation for a input valid
  ngOnInit(): void {
    this.SingUpForm = new FormGroup({
      userName: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [
        Validators.required,
        Validators.maxLength(16),
        Validators.minLength(6),
        Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{2,}')
      ]),
      gender: new FormControl('', [Validators.required]),
      confirmPassword: new FormControl('', [Validators.required]),
    });
  }

  // start function for singup and coniction with dtat base
   SingUp() {
    sessionStorage.removeItem('isset');
    try {
      switch (this.SingUpForm.value['gender']) {
        case '1':
          this.SingUpForm.value['gender'] = true;
          break;
        case '0':
          this.SingUpForm.value['gender'] = false;
          break;
      }
      if (this.SingUpForm.valid ) {
          debugger;
          const fd = new FormData();
          fd.append("userName",this.SingUpForm.value['userName']);
          fd.append("email",this.SingUpForm.value['email']);
          fd.append("password",this.SingUpForm.value['password']);
          fd.append("isAdmin",String(false));
          fd.append("gender",this.SingUpForm.value['gender']);
          fd.append("userImage",this.img);

          this.http.ADDUSER(fd).subscribe(
          (Data: any) => {
            this.res = Data;
            if(this.res)
          {
            debugger;
            let createCart = {
              usersid:this.res.id
            }

            this.cartService.AddCart(createCart).subscribe(
              (Data:CartAPI)=>{console.log(Data);sessionStorage.setItem("CartId",(Data.id).toString());},
              ex=>{console.log(ex);},
            );

            let login = {
              email:this.res.email,
              password:this.SingUpForm.value['password']
            }
            this.http.GetTokenUser(login).subscribe(
              (Data:string)=>{
                this.Token = Data;
                sessionStorage.setItem('Token',this.Token);
                this._Router.navigate(["/"]);
              },
              (err:HttpErrorResponse)=>{
                console.log(err);}
              );
          }
          },
          (err: HttpErrorResponse) => {
            console.log(err);
            sessionStorage.setItem('NotFound',"Try With Other Email or User Name ");
          }
        );
      }
    } catch {
      console.log('err');
    }
  }


  CheckEqual(par)
  {
    if(this.SingUpForm.value['password'] != par)
    {
      this.notEqual = true;
    }
    else{
      this.notEqual = false;
    }
  }
}
