import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-lay-out',
  templateUrl: './auth-lay-out.component.html',
  styleUrls: ['./auth-lay-out.component.css']
})
export class AuthLayOutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
