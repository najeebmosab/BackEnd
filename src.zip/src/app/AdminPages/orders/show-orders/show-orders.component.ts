import { SendEmail } from './../../../shared/model/SendEmail';
import { OrderDetails } from './../../../shared/model/order-details';
import { OrderDetailsService } from 'src/app/shared/Service/order-details.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-orders',
  templateUrl: './show-orders.component.html',
  styleUrls: ['./show-orders.component.css'],
})
export class ShowOrdersComponent implements OnInit {
  constructor(private orderService: OrderDetailsService) {}
  Orders: OrderDetails[] = [];
  isOrder = false;
  totalRecords = 0;
  page: number = 1;
  ngOnInit(): void {
    this.orderService.GetOrderDetailsS().subscribe(
      (Data: Array<OrderDetails>) => {
        console.log(Data);
        this.Orders = Data;
        this.totalRecords = Data.length;
      },
      (ex) => {
        console.log(ex);
      }
    );
  }

  GetOrderById(id) {
    return this.Orders.find((A) => A.id === id);
  }
  ActiveOrder(id, email) {
    var res = this.GetOrderById(id);
    console.log('res', res);
    res.isOrder = !res.isOrder;
    this.orderService.UpdateOrderDetails(id, res).subscribe(
      (Data) => {
        console.log(Data);

        const fd = new FormData();
        fd.append('From', 'najeebmosab@gmail.com');
        fd.append('To', email);
        fd.append('Subject', 'From Eccomers Web Site');
        fd.append('Body',``);
        fd.append('OrderId',String(res.id));
        fd.append('Description', res?.productDescription);
        fd.append('ProductName', res?.productName);
        fd.append('Price', String(res?.productPrice * res?.quantity));
        fd.append('Quantity', String(res?.quantity));
        fd.append(
          'File',
          ' https://localhost:44342/images/products/' + res?.productImage
        );

        this.orderService.SendEmail(fd).subscribe(
          (Data) => {
            console.log('Done');
          },
          (ex) => {
            console.log(ex);
          }
        );
      },
      (ex) => {
        console.log(ex);
      }
    );
  }
  DeleteOrder(id) {
    this.orderService.DeleteOrderDetails(id).subscribe(
      (Data) => {
        console.log(Data);
        this.ngOnInit();
      },
      (ex) => {
        console.log(ex);
      }
    );
  }
}
