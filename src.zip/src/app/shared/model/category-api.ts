export class CategoryAPI {
  id?:number;
  categoryName?:string;
  picture?:string;
}

