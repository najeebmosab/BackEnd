export class SlidersAPI {
  id?:number;
  heading?:string;
  description?:string;
  linke?:string;
  linkeName?:string;
  image?:string;
  status?:boolean;
}
