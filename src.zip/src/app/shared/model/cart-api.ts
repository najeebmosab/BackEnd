import { ProductsAPI } from 'src/app/shared/model/products-api';
export class CartAPI {
  id?:number;
  usersid?:number;
  cartProducts?:ProductsAPI;
}
