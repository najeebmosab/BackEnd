export class UserAPI {
  id?:number;
  userName?:string;
  email?:string;
  password?:string;
  isAdmin?:boolean;
  gender?:boolean;
  userImage?:any;
}
