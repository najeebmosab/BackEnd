export class ImageAPI {
  id?:number;
  productId?:number;
  path?:string;
}
