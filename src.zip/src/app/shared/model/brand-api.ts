export class BrandAPI {
  id?:number;
  name?:string;
  image?:string;
}

