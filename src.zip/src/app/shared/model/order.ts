export class Order {
  id?:number;
  userId?:number;
  email?:string;
  name?:string;
  address?:string;
  city?:string;
  postalCode?:string;
  phone?:string;
  total?:number;
}
