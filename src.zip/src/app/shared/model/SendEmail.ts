export class SendEmail {
   From ?:string ;
   To ?:string ;
   Subject ?:string ;
   Body ?:string ;
}
